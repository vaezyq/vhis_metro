create definer = root@`%` trigger updateLine
    after insert
    on train_data
    for each row
BEGIN

    #     insert train_data_latest SET upload_date='';
    update train_data_latest SET upload_date=new.upload_date, data=new.data;

    #
#     if (exists(select count(1) from train_data_latest)) THEN
#         UPDATE train_data_latest
#         SET upload_date=new.upload_date,
#             data=new.data
#         WHERE upload_date =
#               (select id from (select train_data_latest.upload_date as id from train_data_latest limit 1) as a);
#     ELSE
#         insert train_data_latest SET upload_date=new.upload_date, data=new.data;
#
#     END IF;
END;

